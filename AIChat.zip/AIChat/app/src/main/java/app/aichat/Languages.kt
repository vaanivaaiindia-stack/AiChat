package app.aichat

import java.util.Locale

data class Lang(val code: String, val name: String)

object Languages {
    /** Every language the phone knows about (usually 150+), shown in its own script plus English. */
    val all: List<Lang> by lazy {
        Locale.getAvailableLocales()
            .filter { it.language.isNotEmpty() && it.language.length <= 3 }
            .distinctBy { it.language }
            .map { l ->
                val own = l.getDisplayLanguage(l)
                val en = l.getDisplayLanguage(Locale.ENGLISH)
                Lang(l.language, if (own.equals(en, true)) en else "$own ($en)")
            }
            .sortedBy { it.name.substringAfter('(', it.name).lowercase() }
    }

    /** Languages that have their own strings.xml in this app. */
    val ui = listOf(
        Lang("en", "English"),
        Lang("ml", "മലയാളം"),
        Lang("hi", "हिन्दी"),
        Lang("ta", "தமிழ்")
    )

    fun englishName(code: String): String =
        if (code.isEmpty()) "" else Locale(code).getDisplayLanguage(Locale.ENGLISH)

    fun displayName(code: String): String =
        all.firstOrNull { it.code == code }?.name ?: code

    private val speechRegion = mapOf(
        "en" to "en-US", "ml" to "ml-IN", "hi" to "hi-IN", "ta" to "ta-IN", "te" to "te-IN",
        "kn" to "kn-IN", "bn" to "bn-IN", "mr" to "mr-IN", "gu" to "gu-IN", "pa" to "pa-IN",
        "ur" to "ur-PK", "es" to "es-ES", "fr" to "fr-FR", "de" to "de-DE", "ar" to "ar-SA",
        "pt" to "pt-BR", "ru" to "ru-RU", "ja" to "ja-JP", "ko" to "ko-KR", "zh" to "zh-CN"
    )

    /** Tag for the speech recogniser. */
    fun speechTag(code: String): String =
        if (code.isEmpty()) Locale.getDefault().toLanguageTag() else speechRegion[code] ?: code
}
