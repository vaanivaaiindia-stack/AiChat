package app.aichat

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val plugins = PluginManager(app, prefs)
    val messages = mutableStateListOf<ChatMessage>()
    val pending = mutableStateListOf<Attachment>()
    var loading by mutableStateOf(false)
        private set
    var notice by mutableStateOf<String?>(null)
    private var job: Job? = null

    init {
        // Screenshots taken from the notification arrive here, even while the app is in the background.
        viewModelScope.launch {
            CaptureBus.frames.collect { f ->
                val bytes = withContext(Dispatchers.IO) { f.readBytes() }
                pending.add(Attachment("screen.jpg", "image/jpeg", bytes))
            }
        }
    }

    private fun str(id: Int) = getApplication<Application>().getString(id)

    fun addUri(uri: Uri, asImage: Boolean) {
        viewModelScope.launch {
            try {
                val att = withContext(Dispatchers.IO) { readUri(uri, asImage) }
                if (att != null) pending.add(att)
            } catch (e: Exception) {
                notice = e.message ?: "Could not read file"
            }
        }
    }

    private fun readUri(uri: Uri, asImage: Boolean): Attachment? {
        val cr = getApplication<Application>().contentResolver
        var name = "file"
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        val mime = cr.getType(uri) ?: ""
        val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > 15 * 1024 * 1024) {
            notice = str(R.string.too_big); return null
        }
        return when {
            asImage || mime.startsWith("image/") ->
                Attachment(name, "image/jpeg", compressImage(bytes))
            mime == "application/pdf" || name.endsWith(".pdf", true) ->
                Attachment(name, "application/pdf", bytes)
            mime.startsWith("text/") || listOf(".txt", ".md", ".csv", ".json", ".log")
                .any { name.endsWith(it, true) } ->
                Attachment(name, "text/plain", text = String(bytes, Charsets.UTF_8).take(200_000))
            else -> {
                notice = str(R.string.unsupported); null
            }
        }
    }

    private fun compressImage(bytes: ByteArray): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return bytes
        val scale = 1600f / max(bmp.width, bmp.height)
        val out = if (scale < 1f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        else bmp
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        return bos.toByteArray()
    }

    private fun systemPrompt(): String {
        val code = prefs.aiLang
        val base = "You are a helpful, friendly AI assistant inside a mobile chat app. " +
            "Keep answers clear and well organised."
        return if (code.isEmpty()) "$base Always reply in the same language the user writes in."
        else "$base Always reply in ${Languages.englishName(code)}, using that language's native script."
    }

    fun send(text: String) {
        if (loading) return
        if (text.isBlank() && pending.isEmpty()) return
        val p = Provider.from(prefs.provider)
        val key = prefs.key(p)
        if (key.isBlank()) {
            notice = str(R.string.no_key); return
        }
        messages.add(ChatMessage("user", text.trim(), pending.toList()))
        pending.clear()
        val history = messages.filter { !it.isError && !it.isTool }.toList()
        val model = prefs.model(p)
        var endpoint = p.url
        if (p == Provider.CUSTOM) {
            val u = prefs.customUrl.trimEnd('/')
            if (u.isBlank() || model.isBlank()) {
                notice = str(R.string.need_url_model); return
            }
            endpoint = if (u.endsWith("/chat/completions")) u else "$u/chat/completions"
        }
        val system = systemPrompt()
        loading = true
        job = viewModelScope.launch {
            try {
                val reply = withContext(Dispatchers.IO) {
                    AiClient.chat(
                        p, key, model, system, history, endpoint,
                        tools = plugins.activeTools(),
                        onTool = { messages.add(ChatMessage("assistant", it, isTool = true)) }
                    )
                }
                messages.add(ChatMessage("assistant", reply))
            } catch (e: Exception) {
                messages.add(ChatMessage("assistant", e.message ?: "Error", isError = true))
            } finally {
                loading = false
            }
        }
    }

    fun clear() {
        job?.cancel()
        loading = false
        messages.clear()
        pending.clear()
    }
}
