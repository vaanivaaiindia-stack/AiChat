package app.aichat

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.math.BigDecimal
import java.math.MathContext
import java.net.URI
import java.net.URLEncoder
import kotlin.math.PI
import kotlin.math.abs

/*
 * A plugin is a small JSON file:
 * {
 *   "id": "wikipedia", "name": "Wikipedia", "description": "...",
 *   "settings": [ {"key": "apiKey", "label": "API key"} ],            // optional, user-entered
 *   "tools": [ {
 *       "name": "search", "description": "...",
 *       "parameters": { "type": "object", "properties": { "query": {"type":"string"} }, "required": ["query"] },
 *       "http": { "method": "GET", "url": "https://host/path?q={query}&k={{apiKey}}", "headers": {}, "body": null }
 *       // or  "native": "calculator" | "weather"   (built-in plugins only)
 *   } ]
 * }
 * {param} is replaced with the model's argument, {{key}} with the user's saved setting.
 */

class SettingDef(val key: String, val label: String)

class ToolSpec(
    val name: String,
    val description: String,
    val params: JSONObject,
    val native: String?,
    val method: String,
    val url: String,
    val headers: Map<String, String>,
    val body: String?
)

class Plugin(
    val id: String,
    val name: String,
    val description: String,
    val settings: List<SettingDef>,
    val tools: List<ToolSpec>,
    val builtin: Boolean
) {
    /** Websites this plugin can contact (shown to the user before installing). */
    fun hosts(): Set<String> {
        val out = linkedSetOf<String>()
        for (t in tools) {
            if (t.native == "weather") {
                out.add("api.open-meteo.com"); out.add("geocoding-api.open-meteo.com")
            }
            if (t.url.isNotBlank()) {
                val host = try {
                    URI(t.url.replace("{", "").replace("}", "")).host
                } catch (_: Exception) {
                    null
                }
                if (host != null) out.add(host)
            }
        }
        return out
    }
}

object PluginParser {
    private val idRe = Regex("^[a-z0-9_]{1,24}$")
    private val nameRe = Regex("^[a-zA-Z0-9_]{1,30}$")
    private val nativeTools = setOf("calculator", "weather")

    fun parse(json: String, builtin: Boolean): Plugin {
        val j = JSONObject(json)
        val id = j.getString("id")
        require(idRe.matches(id)) { "Plugin id must be lowercase letters, digits or _ (max 24)" }
        val settings = mutableListOf<SettingDef>()
        j.optJSONArray("settings")?.let { a ->
            for (i in 0 until a.length()) {
                val s = a.getJSONObject(i)
                settings.add(SettingDef(s.getString("key"), s.optString("label", s.getString("key"))))
            }
        }
        val ta = j.getJSONArray("tools")
        require(ta.length() in 1..8) { "A plugin needs 1 to 8 tools" }
        val tools = mutableListOf<ToolSpec>()
        for (i in 0 until ta.length()) {
            val t = ta.getJSONObject(i)
            val name = t.getString("name")
            require(nameRe.matches(name)) { "Bad tool name: $name" }
            val params = t.optJSONObject("parameters") ?: JSONObject()
            if (!params.has("type")) params.put("type", "object")
            if (!params.has("properties")) params.put("properties", JSONObject())
            val native = t.optString("native").ifBlank { null }
            if (native != null) {
                require(builtin && native in nativeTools) { "Native tools are only for built-in plugins" }
                tools.add(ToolSpec(name, t.getString("description"), params, native, "GET", "", emptyMap(), null))
            } else {
                val http = t.getJSONObject("http")
                val url = http.getString("url")
                require(url.startsWith("https://")) { "Only https:// URLs are allowed" }
                val headers = mutableMapOf<String, String>()
                http.optJSONObject("headers")?.let { h -> h.keys().forEach { k -> headers[k] = h.getString(k) } }
                val body = if (http.isNull("body")) null else http.optString("body").ifBlank { null }
                tools.add(
                    ToolSpec(
                        name, t.getString("description"), params, null,
                        http.optString("method", "GET").uppercase(), url, headers, body
                    )
                )
            }
        }
        return Plugin(id, j.optString("name", id), j.optString("description"), settings, tools, builtin)
    }
}

class PluginManager(private val ctx: Context, private val prefs: Prefs) {
    private val dir get() = File(ctx.filesDir, "plugins").apply { mkdirs() }

    fun catalog(): List<Plugin> {
        val out = mutableListOf<Plugin>()
        ctx.assets.list("plugins")?.sorted()?.forEach { f ->
            try {
                out.add(PluginParser.parse(ctx.assets.open("plugins/$f").bufferedReader().use { it.readText() }, true))
            } catch (_: Exception) {
            }
        }
        dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
            try {
                out.add(PluginParser.parse(f.readText(), false))
            } catch (_: Exception) {
            }
        }
        return out
    }

    private fun idSet(k: String) = prefs.raw(k).split(",").filter { it.isNotBlank() }.toMutableSet()
    private fun saveSet(k: String, s: Set<String>) = prefs.setRaw(k, s.joinToString(","))

    fun isInstalled(id: String) = id in idSet("plugins_installed")
    fun isEnabled(id: String) = id !in idSet("plugins_disabled")

    fun install(id: String) {
        saveSet("plugins_installed", idSet("plugins_installed").apply { add(id) })
        saveSet("plugins_disabled", idSet("plugins_disabled").apply { remove(id) })
    }

    fun uninstall(id: String) {
        saveSet("plugins_installed", idSet("plugins_installed").apply { remove(id) })
        File(dir, "$id.json").delete() // only custom plugins live here
    }

    fun setEnabled(id: String, on: Boolean) =
        saveSet("plugins_disabled", idSet("plugins_disabled").apply { if (on) remove(id) else add(id) })

    fun setting(id: String, key: String) = prefs.raw("plugin_${id}_$key")
    fun setSetting(id: String, key: String, v: String) = prefs.setRaw("plugin_${id}_$key", v.trim())

    /** Validates and saves a user-added plugin, then installs it. */
    fun addCustom(json: String): Plugin {
        val p = PluginParser.parse(json, false)
        require(catalog().none { it.id == p.id && it.builtin }) { "A built-in plugin already uses this id" }
        File(dir, "${p.id}.json").writeText(json)
        install(p.id)
        return p
    }

    fun activeTools(): List<ToolDef> {
        val on = idSet("plugins_installed") - idSet("plugins_disabled")
        val out = mutableListOf<ToolDef>()
        for (p in catalog()) {
            if (p.id !in on) continue
            for (t in p.tools) {
                out.add(
                    ToolDef("${p.id}_${t.name}", p.name, t.description, t.params) { args -> run(p, t, args) }
                )
            }
        }
        return out
    }

    // ---------- execution ----------
    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8").replace("+", "%20")

    private fun run(p: Plugin, t: ToolSpec, args: JSONObject): String =
        when (t.native) {
            "calculator" -> Calc.eval(args.optString("expression"))
            "weather" -> weather(args.optString("location"))
            else -> http(p, t, args)
        }

    private fun fill(p: Plugin, t: ToolSpec, args: JSONObject, text: String, f: (String) -> String): String {
        var r = text
        for (s in p.settings) r = r.replace("{{${s.key}}}", f(setting(p.id, s.key)))
        t.params.optJSONObject("properties")?.keys()?.forEach { k ->
            r = r.replace("{$k}", f(args.opt(k)?.toString() ?: ""))
        }
        return r
    }

    private fun http(p: Plugin, t: ToolSpec, args: JSONObject): String {
        val url = fill(p, t, args, t.url) { enc(it) }
        require(url.startsWith("https://")) { "Only https:// is allowed" }
        val headers = t.headers.mapValues { fill(p, t, args, it.value) { v -> v } }
        val body = t.body?.let { fill(p, t, args, it) { v -> JSONObject.quote(v).drop(1).dropLast(1) } }
        return AiClient.fetch(t.method, url, headers, body)
    }

    private fun weather(location: String): String {
        if (location.isBlank()) return "Error: location is required"
        val geo = JSONObject(
            AiClient.fetch(
                "GET", "https://geocoding-api.open-meteo.com/v1/search?name=${enc(location)}&count=1&format=json",
                emptyMap(), null
            )
        )
        val r = geo.optJSONArray("results")?.optJSONObject(0) ?: return "Location not found: $location"
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")
        val f = AiClient.fetch(
            "GET",
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=3",
            emptyMap(), null
        )
        return "Place: ${r.optString("name")}, ${r.optString("country")}\n$f\n" +
            "(units: °C, km/h, mm; weather_code is the WMO code)"
    }
}

/** Small safe calculator: + - * / % ^ ( ) and sqrt, sin, cos, tan, ln, log, abs, pi, e. */
object Calc {
    fun eval(input: String): String {
        if (input.isBlank()) return "Error: expression is required"
        return try {
            val s = input.replace(" ", "").replace("×", "*").replace("÷", "/").replace(",", "")
            val v = P(s).parse()
            if (v.isNaN() || v.isInfinite()) "Error: result is not a number"
            else if (v == Math.rint(v) && abs(v) < 1e15) v.toLong().toString()
            else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private class P(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i < s.length) throw IllegalArgumentException("Unexpected '${s[i]}'")
            return v
        }

        fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val t = term()
                v = if (op == '+') v + t else v - t
            }
            return v
        }

        fun term(): Double {
            var v = power()
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                val op = s[i++]
                val t = power()
                v = when (op) {
                    '*' -> v * t
                    '/' -> v / t
                    else -> v % t
                }
            }
            return v
        }

        fun power(): Double {
            val b = unary()
            if (peek() == '^') {
                i++
                return Math.pow(b, power())
            }
            return b
        }

        fun unary(): Double {
            if (peek() == '-') {
                i++; return -unary()
            }
            if (peek() == '+') {
                i++; return unary()
            }
            return atom()
        }

        fun atom(): Double {
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("Missing )")
                i++
                return v
            }
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            if (st != i) return s.substring(st, i).toDouble()
            while (peek().isLetter()) i++
            val name = s.substring(st, i)
            if (name.isEmpty()) throw IllegalArgumentException("Bad expression near position $i")
            if (name == "pi") return PI
            if (name == "e") return Math.E
            if (peek() != '(') throw IllegalArgumentException("Unknown name '$name'")
            i++
            val a = expr()
            if (peek() != ')') throw IllegalArgumentException("Missing )")
            i++
            return when (name) {
                "sqrt" -> Math.sqrt(a)
                "sin" -> Math.sin(a)
                "cos" -> Math.cos(a)
                "tan" -> Math.tan(a)
                "ln" -> Math.log(a)
                "log" -> Math.log10(a)
                "abs" -> abs(a)
                else -> throw IllegalArgumentException("Unknown function '$name'")
            }
        }
    }
}
