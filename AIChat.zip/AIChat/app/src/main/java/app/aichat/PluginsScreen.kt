package app.aichat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

private const val EXAMPLE = """{
  "id": "books",
  "name": "Open Library",
  "description": "Search books",
  "tools": [{
    "name": "search",
    "description": "Search books by title or author",
    "parameters": {
      "type": "object",
      "properties": { "query": { "type": "string" } },
      "required": ["query"]
    },
    "http": {
      "method": "GET",
      "url": "https://openlibrary.org/search.json?q={query}&limit=5"
    }
  }]
}"""

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PluginsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val pm = vm.plugins
    var tick by remember { mutableStateOf(0) }
    val catalog = remember(tick) { pm.catalog() }
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.plugins)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
                }
            }
        )
    }) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text(stringResource(R.string.plugin_hint), style = MaterialTheme.typography.bodySmall) }
            items(catalog, key = { it.id }) { p -> PluginCard(p, pm) { tick++ } }
            item {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.add_plugin))
                }
            }
            item { Column(Modifier.padding(8.dp)) {} }
        }
    }

    if (showAdd) AddPluginDialog(pm) { showAdd = false; tick++ }
}

@Composable
private fun PluginCard(p: Plugin, pm: PluginManager, changed: () -> Unit) {
    val installed = pm.isInstalled(p.id)
    var enabled by remember(p) { mutableStateOf(pm.isEnabled(p.id)) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (installed) Switch(checked = enabled, onCheckedChange = {
                    enabled = it; pm.setEnabled(p.id, it)
                })
            }
            if (p.description.isNotBlank()) Text(p.description, style = MaterialTheme.typography.bodyMedium)
            val hosts = p.hosts()
            if (hosts.isNotEmpty()) {
                Text(
                    stringResource(R.string.plugin_contacts, hosts.joinToString(", ")),
                    style = MaterialTheme.typography.labelSmall
                )
            }
            if (installed) p.settings.forEach { s ->
                var v by remember(p) { mutableStateOf(pm.setting(p.id, s.key)) }
                OutlinedTextField(
                    value = v,
                    onValueChange = { v = it; pm.setSetting(p.id, s.key, it) },
                    label = { Text(s.label) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (installed) OutlinedButton(onClick = { pm.uninstall(p.id); changed() }) {
                Text(stringResource(R.string.remove))
            } else Button(onClick = { pm.install(p.id); changed() }) {
                Text(stringResource(R.string.install))
            }
        }
    }
}

@Composable
private fun AddPluginDialog(pm: PluginManager, onDone: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    // live check, so the user sees which sites the plugin will contact before adding it
    val parsed = remember(text) {
        if (text.isBlank()) null
        else try {
            Result.success(PluginParser.parse(text, false))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(stringResource(R.string.add_plugin)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it; error = null },
                    label = { Text(stringResource(R.string.paste_json)) },
                    placeholder = { Text(EXAMPLE) },
                    minLines = 6, maxLines = 10,
                    modifier = Modifier.fillMaxWidth()
                )
                parsed?.onSuccess {
                    Text(
                        stringResource(R.string.plugin_contacts, it.hosts().joinToString(", ")),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                parsed?.onFailure {
                    Text(it.message ?: "Invalid JSON", color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelMedium)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = parsed?.isSuccess == true,
                onClick = {
                    try {
                        pm.addCustom(text); onDone()
                    } catch (e: Exception) {
                        error = e.message
                    }
                }
            ) { Text(stringResource(R.string.add)) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.cancel)) } }
    )
}
