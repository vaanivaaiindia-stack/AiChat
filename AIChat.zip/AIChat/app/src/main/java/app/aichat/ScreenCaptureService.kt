package app.aichat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.io.FileOutputStream

/** Connects the capture service to the chat screen. */
object CaptureBus {
    val frames = MutableSharedFlow<File>(extraBufferCapacity = 4)
    val active = MutableStateFlow(false)
}

/**
 * Screen sharing with the AI: user starts it once, goes to any screen, pulls down the
 * notification and taps "Capture". The screenshot is added to the chat as an image.
 */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var w = 0
    private var h = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_CAPTURE -> capture()
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen sharing", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, 1, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
        if (data == null) {
            stopAll(); return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() = stopAll()
        }, Handler(Looper.getMainLooper()))
        projection = mp

        val dm = resources.displayMetrics
        w = dm.widthPixels
        h = dm.heightPixels
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = mp.createVirtualDisplay(
            "ai-chat-capture", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        CaptureBus.active.value = true
    }

    private fun capture() {
        val img = reader?.acquireLatestImage() ?: return
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * w
            val full = Bitmap.createBitmap(
                w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            val shot = Bitmap.createBitmap(full, 0, 0, w, h)
            val f = File(cacheDir, "screen_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { shot.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            CaptureBus.frames.tryEmit(f)
            Toast.makeText(this, getString(R.string.captured), Toast.LENGTH_SHORT).show()
        } finally {
            img.close()
        }
    }

    private fun stopAll() {
        CaptureBus.active.value = false
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun action(act: String, req: Int) = PendingIntent.getService(
        this, req, Intent(this, ScreenCaptureService::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle(getString(R.string.sharing_title))
            .setContentText(getString(R.string.share_hint))
            .setOngoing(true)
            .addAction(0, getString(R.string.capture), action(ACTION_CAPTURE, 1))
            .addAction(0, getString(R.string.stop), action(ACTION_STOP, 2))
            .build()

    override fun onDestroy() {
        CaptureBus.active.value = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "app.aichat.START"
        const val ACTION_CAPTURE = "app.aichat.CAPTURE"
        const val ACTION_STOP = "app.aichat.STOP"
        private const val CHANNEL = "screen_share"
    }
}
