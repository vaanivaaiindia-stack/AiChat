package app.aichat

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class Attachment(
    val name: String,
    val mime: String,
    val bytes: ByteArray? = null,
    val text: String? = null
) {
    val isImage get() = mime.startsWith("image/")
    val isPdf get() = mime == "application/pdf"
}

class ChatMessage(
    val role: String, // "user" or "assistant"
    val text: String,
    val attachments: List<Attachment> = emptyList(),
    val isError: Boolean = false,
    val isTool: Boolean = false // small "plugin used" note, never sent to the AI
)

/** One function the AI may call. [run] executes it and returns text for the AI. */
class ToolDef(
    val name: String,
    val plugin: String,
    val description: String,
    val params: JSONObject,
    val run: (JSONObject) -> String
)

object AiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()
    private const val MAX_ROUNDS = 5

    /** Blocking call: run it off the main thread. */
    fun chat(
        provider: Provider, key: String, model: String,
        system: String, history: List<ChatMessage>, endpoint: String = "",
        tools: List<ToolDef> = emptyList(), onTool: (String) -> Unit = {}
    ): String {
        fun go(t: List<ToolDef>) = when (provider) {
            Provider.CLAUDE -> claude(key, model, system, history, t, onTool)
            Provider.GEMINI -> gemini(key, model, system, history, t, onTool)
            else -> compat(endpoint, key, model, system, history, provider.images, provider.pdf, t, onTool)
        }
        return try {
            go(tools)
        } catch (e: RuntimeException) {
            val m = e.message.orEmpty()
            val toolsRejected = tools.isNotEmpty() &&
                (m.startsWith("HTTP 400") || m.startsWith("HTTP 404") || m.startsWith("HTTP 422"))
            if (!toolsRejected) throw e
            onTool("⚠ This model does not support plugins. Answering without them.")
            go(emptyList())
        }
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun safe(t: String) = t.ifBlank { "(see attachment)" }

    /** Only the newest user message carries the full file bytes; older ones are just named. */
    private fun note(a: Attachment) = "[attached earlier: ${a.name}]"
    private fun fileText(a: Attachment) = "[File: ${a.name}]\n${a.text}"

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val rb = Request.Builder().url(url).post(body.toString().toRequestBody(JSON))
        headers.forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = try {
                    val j = JSONObject(raw)
                    val e = j.opt("error")
                    if (e is JSONObject) e.optString("message") else e?.toString()
                } catch (_: Exception) {
                    null
                }
                throw RuntimeException("HTTP ${resp.code}: ${msg ?: raw.take(300)}")
            }
            return JSONObject(raw)
        }
    }

    /** Plain HTTP request used by plugins. Never throws for HTTP errors; the text goes back to the AI. */
    fun fetch(method: String, url: String, headers: Map<String, String>, body: String?): String {
        val rb = Request.Builder().url(url).header("User-Agent", "AIChatApp/1.0 (Android)")
        headers.forEach { (k, v) -> rb.header(k, v) }
        val m = method.uppercase()
        if (m == "GET") rb.get() else rb.method(m, (body ?: "").toRequestBody(JSON))
        http.newCall(rb.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            val t = if (raw.length > 6000) raw.take(6000) + "\n…(truncated)" else raw
            return if (resp.isSuccessful) t else "HTTP ${resp.code}: ${t.take(300)}"
        }
    }

    private fun runTool(tools: List<ToolDef>, name: String, args: JSONObject, onTool: (String) -> Unit): String {
        val t = tools.firstOrNull { it.name == name } ?: return "Error: unknown tool $name"
        onTool("🔧 ${t.plugin}: ${args.toString().take(120)}")
        return try {
            t.run(args)
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun hasParams(t: ToolDef) = (t.params.optJSONObject("properties")?.length() ?: 0) > 0

    // ---------- Claude ----------
    private fun claude(
        key: String, model: String, system: String, h: List<ChatMessage>,
        tools: List<ToolDef>, onTool: (String) -> Unit
    ): String {
        val last = h.indexOfLast { it.role == "user" }
        val msgs = JSONArray()
        h.forEachIndexed { i, m ->
            val c = JSONArray()
            for (a in m.attachments) {
                when {
                    i != last -> c.put(textBlock(note(a)))
                    a.isImage -> c.put(
                        JSONObject().put("type", "image").put(
                            "source", JSONObject().put("type", "base64")
                                .put("media_type", a.mime).put("data", b64(a.bytes!!))
                        )
                    )
                    a.isPdf -> c.put(
                        JSONObject().put("type", "document").put(
                            "source", JSONObject().put("type", "base64")
                                .put("media_type", "application/pdf").put("data", b64(a.bytes!!))
                        )
                    )
                    else -> c.put(textBlock(fileText(a)))
                }
            }
            c.put(textBlock(safe(m.text)))
            msgs.put(JSONObject().put("role", m.role).put("content", c))
        }
        val toolsJson = JSONArray()
        tools.forEach {
            toolsJson.put(
                JSONObject().put("name", it.name).put("description", it.description)
                    .put("input_schema", it.params)
            )
        }
        var round = 0
        while (true) {
            val body = JSONObject().put("model", model).put("max_tokens", 4096)
                .put("system", system).put("messages", msgs)
            if (tools.isNotEmpty()) body.put("tools", toolsJson)
            val r = post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body
            )
            val arr = r.getJSONArray("content")
            val blocks = (0 until arr.length()).map { arr.getJSONObject(it) }
            val calls = blocks.filter { it.optString("type") == "tool_use" }
            if (calls.isEmpty() || tools.isEmpty() || round >= MAX_ROUNDS) {
                return blocks.filter { it.optString("type") == "text" }
                    .joinToString("") { it.optString("text") }
                    .ifBlank { if (calls.isNotEmpty()) "(stopped after too many plugin calls)" else "(empty reply)" }
            }
            msgs.put(JSONObject().put("role", "assistant").put("content", arr))
            val results = JSONArray()
            for (c in calls) {
                val out = runTool(tools, c.getString("name"), c.optJSONObject("input") ?: JSONObject(), onTool)
                results.put(
                    JSONObject().put("type", "tool_result")
                        .put("tool_use_id", c.getString("id")).put("content", out)
                )
            }
            msgs.put(JSONObject().put("role", "user").put("content", results))
            round++
        }
    }

    private fun textBlock(t: String) = JSONObject().put("type", "text").put("text", t)

    // ---------- Gemini ----------
    private fun gemini(
        key: String, model: String, system: String, h: List<ChatMessage>,
        tools: List<ToolDef>, onTool: (String) -> Unit
    ): String {
        val last = h.indexOfLast { it.role == "user" }
        val contents = JSONArray()
        h.forEachIndexed { i, m ->
            val parts = JSONArray()
            for (a in m.attachments) {
                when {
                    i != last -> parts.put(JSONObject().put("text", note(a)))
                    a.isImage || a.isPdf -> parts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject().put("mimeType", a.mime).put("data", b64(a.bytes!!))
                        )
                    )
                    else -> parts.put(JSONObject().put("text", fileText(a)))
                }
            }
            parts.put(JSONObject().put("text", safe(m.text)))
            contents.put(
                JSONObject().put("role", if (m.role == "assistant") "model" else "user")
                    .put("parts", parts)
            )
        }
        val decls = JSONArray()
        tools.forEach {
            val d = JSONObject().put("name", it.name).put("description", it.description)
            if (hasParams(it)) d.put("parameters", it.params) // Gemini rejects empty object schemas
            decls.put(d)
        }
        var round = 0
        while (true) {
            val body = JSONObject().put("contents", contents).put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            if (tools.isNotEmpty()) {
                body.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
            }
            val r = post(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("x-goog-api-key" to key), body
            )
            val cand = r.optJSONArray("candidates")?.optJSONObject(0)
                ?: throw RuntimeException(
                    "Blocked or empty reply: " + r.optJSONObject("promptFeedback")?.toString()
                )
            val content = cand.optJSONObject("content")
            val parts = content?.optJSONArray("parts") ?: JSONArray()
            val list = (0 until parts.length()).map { parts.getJSONObject(it) }
            val calls = list.filter { it.has("functionCall") }
            if (calls.isEmpty() || tools.isEmpty() || round >= MAX_ROUNDS) {
                return list.filter { !it.optBoolean("thought") }
                    .joinToString("") { it.optString("text") }
                    .ifBlank {
                        if (calls.isNotEmpty()) "(stopped after too many plugin calls)"
                        else "(empty reply: ${cand.optString("finishReason")})"
                    }
            }
            // echo the model turn exactly as received (keeps any thought signatures)
            contents.put(content)
            val responses = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val out = runTool(tools, fc.getString("name"), fc.optJSONObject("args") ?: JSONObject(), onTool)
                responses.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject().put("name", fc.getString("name"))
                            .put("response", JSONObject().put("result", out))
                    )
                )
            }
            contents.put(JSONObject().put("role", "user").put("parts", responses))
            round++
        }
    }

    // ---------- OpenAI-compatible (OpenAI, DeepSeek, Groq, OpenRouter, Mistral, xAI, ...) ----------
    private fun compat(
        url: String, key: String, model: String, system: String,
        h: List<ChatMessage>, images: Boolean, pdf: Boolean,
        tools: List<ToolDef>, onTool: (String) -> Unit
    ): String {
        val last = h.indexOfLast { it.role == "user" }
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        h.forEachIndexed { i, m ->
            if (m.role == "assistant") {
                msgs.put(JSONObject().put("role", "assistant").put("content", m.text))
                return@forEachIndexed
            }
            if (!images) {
                // text-only providers want a plain string
                val text = buildString {
                    for (a in m.attachments) {
                        when {
                            i != last -> append(note(a)).append("\n")
                            a.text != null -> append(fileText(a)).append("\n\n")
                            else -> append("[${a.name} was not sent: this provider reads text only]\n")
                        }
                    }
                    append(safe(m.text))
                }
                msgs.put(JSONObject().put("role", "user").put("content", text))
                return@forEachIndexed
            }
            val c = JSONArray()
            for (a in m.attachments) {
                when {
                    i != last -> c.put(oaText(note(a)))
                    a.isImage -> c.put(
                        JSONObject().put("type", "image_url").put(
                            "image_url",
                            JSONObject().put("url", "data:${a.mime};base64,${b64(a.bytes!!)}")
                        )
                    )
                    a.isPdf && pdf -> c.put(
                        JSONObject().put("type", "file").put(
                            "file", JSONObject().put("filename", a.name)
                                .put("file_data", "data:application/pdf;base64,${b64(a.bytes!!)}")
                        )
                    )
                    a.isPdf -> c.put(oaText("[${a.name} was not sent: this provider does not read PDF]"))
                    else -> c.put(oaText(fileText(a)))
                }
            }
            c.put(oaText(safe(m.text)))
            msgs.put(JSONObject().put("role", "user").put("content", c))
        }
        val toolsJson = JSONArray()
        tools.forEach {
            toolsJson.put(
                JSONObject().put("type", "function").put(
                    "function",
                    JSONObject().put("name", it.name).put("description", it.description)
                        .put("parameters", it.params)
                )
            )
        }
        var round = 0
        while (true) {
            val body = JSONObject().put("model", model).put("messages", msgs).put("stream", false)
            if (tools.isNotEmpty()) body.put("tools", toolsJson)
            val r = post(url, mapOf("Authorization" to "Bearer $key"), body)
            val msg = r.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
            val calls = msg.optJSONArray("tool_calls")
            if (calls == null || calls.length() == 0 || tools.isEmpty() || round >= MAX_ROUNDS) {
                return msg.optString("content").let { if (it == "null") "" else it }
                    .ifBlank { if (calls != null && calls.length() > 0) "(stopped after too many plugin calls)" else "(empty reply)" }
            }
            msgs.put(msg)
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                val fn = c.getJSONObject("function")
                val args = try {
                    JSONObject(fn.optString("arguments").ifBlank { "{}" })
                } catch (_: Exception) {
                    JSONObject()
                }
                val out = runTool(tools, fn.getString("name"), args, onTool)
                msgs.put(
                    JSONObject().put("role", "tool").put("tool_call_id", c.getString("id")).put("content", out)
                )
            }
            round++
        }
    }

    private fun oaText(t: String) = JSONObject().put("type", "text").put("text", t)
}
