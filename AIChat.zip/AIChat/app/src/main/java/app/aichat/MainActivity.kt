package app.aichat

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ui = Prefs(this).uiLang
        if (ui.isNotEmpty()) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(ui))
        }
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val vm: ChatViewModel = viewModel()
    var screen by remember {
        mutableStateOf(if (vm.prefs.key(Provider.from(vm.prefs.provider)).isBlank()) "settings" else "chat")
    }
    when (screen) {
        "settings" -> SettingsScreen(vm, onPlugins = { screen = "plugins" }) { screen = "chat" }
        "plugins" -> PluginsScreen(vm) { screen = "settings" }
        else -> ChatScreen(vm) { screen = "settings" }
    }
}

// ======================= CHAT =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm.notice) {
        vm.notice?.let { snackbar.showSnackbar(it); vm.notice = null }
    }
    LaunchedEffect(vm.messages.size, vm.loading) {
        val count = vm.messages.size + if (vm.loading) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    // ---- file pickers ----
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { vm.addUri(it, true) }
    }
    val pickDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.addUri(it, false) }
    }

    // ---- screen sharing ----
    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK && r.data != null) {
            val i = Intent(ctx, ScreenCaptureService::class.java)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra("code", r.resultCode)
                .putExtra("data", r.data)
            ContextCompat.startForegroundService(ctx, i)
            vm.notice = ctx.getString(R.string.share_hint)
        }
    }
    fun launchProjection() {
        val mpm = ctx.getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        launchProjection()
    }
    fun startShare() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else launchProjection()
    }
    fun stopShare() {
        ctx.startService(
            Intent(ctx, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)
        )
    }

    // ---- screen mirroring: hand over to Android's own Cast / Smart View screen ----
    fun mirror() {
        try {
            ctx.startActivity(Intent("android.settings.CAST_SETTINGS"))
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    // ---- voice input ----
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null
    }
    DisposableEffect(Unit) { onDispose { recognizer?.destroy() } }

    fun startListening() {
        val r = recognizer ?: run { vm.notice = ctx.getString(R.string.no_speech); return }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) input = (input + " " + t).trim()
                listening = false
            }

            override fun onError(error: Int) {
                listening = false
                vm.notice = ctx.getString(R.string.speech_error)
            }

            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Languages.speechTag(vm.prefs.aiLang))
        listening = true
        r.startListening(i)
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startListening()
    }
    fun onMic() {
        if (listening) {
            recognizer?.stopListening(); listening = false; return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) startListening()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, stringResource(R.string.settings))
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.share_screen)) },
                                onClick = { menu = false; startShare() })
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.stop_share)) },
                                onClick = { menu = false; stopShare() })
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.mirror)) },
                                onClick = { menu = false; mirror() })
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.new_chat)) },
                                onClick = { menu = false; vm.clear() })
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(Modifier.padding(8.dp)) {
                if (vm.pending.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        vm.pending.toList().forEach { a ->
                            AssistChip(
                                onClick = { vm.pending.remove(a) },
                                label = { Text(a.name, maxLines = 1) },
                                trailingIcon = { Icon(Icons.Default.Close, null) }
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { pickImage.launch("image/*") }) {
                        Icon(Icons.Default.Image, stringResource(R.string.attach_image))
                    }
                    IconButton(onClick = {
                        pickDoc.launch(arrayOf("application/pdf", "text/*", "application/json"))
                    }) { Icon(Icons.Default.AttachFile, stringResource(R.string.attach_doc)) }
                    IconButton(onClick = { onMic() }) {
                        Icon(
                            if (listening) Icons.Default.Stop else Icons.Default.Mic,
                            stringResource(R.string.voice),
                            tint = if (listening) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text(stringResource(R.string.hint)) },
                        modifier = Modifier.weight(1f),
                        maxLines = 5
                    )
                    IconButton(
                        enabled = !vm.loading,
                        onClick = { vm.send(input); input = "" }
                    ) { Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.send)) }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (vm.messages.isEmpty() && !vm.loading) {
                Text(
                    stringResource(R.string.empty),
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(vm.messages.toList()) { m -> Bubble(m) }
                if (vm.loading) item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                        CircularProgressIndicator(Modifier.padding(end = 8.dp), strokeWidth = 2.dp)
                        Text(stringResource(R.string.thinking))
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    if (m.isTool) {
        Text(
            m.text,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        return
    }
    val mine = m.role == "user"
    val bg = when {
        m.isError -> MaterialTheme.colorScheme.errorContainer
        mine -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Surface(color = bg, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)) {
            SelectionContainer {
                Column(Modifier.padding(12.dp)) {
                    m.attachments.forEach {
                        Text("📎 ${it.name}", style = MaterialTheme.typography.labelMedium)
                    }
                    if (m.text.isNotBlank()) Text(m.text)
                }
            }
        }
    }
}

// ======================= SETTINGS =======================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onPlugins: () -> Unit, onDone: () -> Unit) {
    val prefs = vm.prefs
    var provider by remember { mutableStateOf(Provider.from(prefs.provider)) }
    var key by remember(provider) { mutableStateOf(prefs.key(provider)) }
    var model by remember(provider) { mutableStateOf(prefs.model(provider)) }
    var showKey by remember { mutableStateOf(false) }
    var customUrl by remember { mutableStateOf(prefs.customUrl) }
    var aiLang by remember { mutableStateOf(prefs.aiLang) }
    var uiLang by remember { mutableStateOf(prefs.uiLang) }
    var picker by remember { mutableStateOf(0) } // 0 none, 1 reply language, 2 app language

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = {
                IconButton(onClick = onDone) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
                }
            }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.provider), style = MaterialTheme.typography.titleSmall)
            Provider.values().forEach { p ->
                Row(
                    Modifier.fillMaxWidth().selectable(selected = p == provider, onClick = { provider = p }),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = p == provider, onClick = { provider = p })
                    Text(p.label)
                }
            }
            if (provider == Provider.CUSTOM) {
                OutlinedTextField(
                    value = customUrl, onValueChange = { customUrl = it },
                    label = { Text(stringResource(R.string.base_url)) },
                    placeholder = { Text("https://host/v1") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(
                    stringResource(R.string.get_key, provider.keyUrl),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = key, onValueChange = { key = it },
                label = { Text(stringResource(R.string.api_key)) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "🙈" else "👁") }
                }
            )
            Text(stringResource(R.string.key_note), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = model, onValueChange = { model = it },
                label = { Text(stringResource(R.string.model)) },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.ai_language), style = MaterialTheme.typography.titleSmall)
            OutlinedButton(onClick = { picker = 1 }, modifier = Modifier.fillMaxWidth()) {
                Text(if (aiLang.isEmpty()) stringResource(R.string.auto) else Languages.displayName(aiLang))
            }
            Text(stringResource(R.string.ui_language), style = MaterialTheme.typography.titleSmall)
            OutlinedButton(onClick = { picker = 2 }, modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (uiLang.isEmpty()) stringResource(R.string.system_default)
                    else Languages.ui.firstOrNull { it.code == uiLang }?.name ?: uiLang
                )
            }

            OutlinedButton(onClick = onPlugins, modifier = Modifier.fillMaxWidth()) {
                Text("🧩 " + stringResource(R.string.plugins))
            }

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val uiChanged = uiLang != prefs.uiLang
                    prefs.provider = provider.id
                    prefs.setKey(provider, key)
                    prefs.setModel(provider, model)
                    prefs.aiLang = aiLang
                    prefs.customUrl = customUrl
                    prefs.uiLang = uiLang
                    if (uiChanged) {
                        AppCompatDelegate.setApplicationLocales(
                            if (uiLang.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                            else LocaleListCompat.forLanguageTags(uiLang)
                        )
                    }
                    onDone()
                }
            ) { Text(stringResource(R.string.save)) }
        }
    }

    if (picker == 1) LanguageDialog(
        options = Languages.all,
        autoLabel = stringResource(R.string.auto),
        searchable = true,
        onPick = { aiLang = it; picker = 0 },
        onDismiss = { picker = 0 }
    )
    if (picker == 2) LanguageDialog(
        options = Languages.ui,
        autoLabel = stringResource(R.string.system_default),
        searchable = false,
        onPick = { uiLang = it; picker = 0 },
        onDismiss = { picker = 0 }
    )
}

@Composable
private fun LanguageDialog(
    options: List<Lang>, autoLabel: String, searchable: Boolean,
    onPick: (String) -> Unit, onDismiss: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val filtered = remember(q, options) {
        if (q.isBlank()) options else options.filter { it.name.contains(q, ignoreCase = true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("✕") } },
        text = {
            Column {
                if (searchable) OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    label = { Text(stringResource(R.string.search)) },
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.weight(1f, fill = false).widthIn(min = 240.dp)) {
                    item {
                        Text(
                            autoLabel,
                            Modifier.fillMaxWidth().selectable(selected = false, onClick = { onPick("") })
                                .padding(vertical = 12.dp)
                        )
                    }
                    items(filtered) { l ->
                        Text(
                            l.name,
                            Modifier.fillMaxWidth().selectable(selected = false, onClick = { onPick(l.code) })
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    )
}
