package app.aichat

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class Provider(
    val id: String, val label: String, val defaultModel: String,
    val url: String, val keyUrl: String, val images: Boolean, val pdf: Boolean
) {
    CLAUDE("claude", "Claude (Anthropic)", "claude-sonnet-5-5", "", "console.anthropic.com", true, true),
    GEMINI("gemini", "Google Gemini (free tier)", "gemini-2.5-flash", "", "aistudio.google.com/apikey", true, true),
    OPENAI("openai", "OpenAI (ChatGPT)", "gpt-4o-mini", "https://api.openai.com/v1/chat/completions", "platform.openai.com/api-keys", true, true),
    DEEPSEEK("deepseek", "DeepSeek (text only)", "deepseek-chat", "https://api.deepseek.com/chat/completions", "platform.deepseek.com/api_keys", false, false),
    GROQ("groq", "Groq (free tier, text only)", "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1/chat/completions", "console.groq.com/keys", false, false),
    OPENROUTER("openrouter", "OpenRouter (has free models)", "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/api/v1/chat/completions", "openrouter.ai/keys", true, false),
    MISTRAL("mistral", "Mistral", "mistral-small-latest", "https://api.mistral.ai/v1/chat/completions", "console.mistral.ai/api-keys", true, false),
    XAI("xai", "xAI (Grok)", "grok-4", "https://api.x.ai/v1/chat/completions", "console.x.ai", true, false),
    TOGETHER("together", "Together AI (text only)", "meta-llama/Llama-3.3-70B-Instruct-Turbo", "https://api.together.xyz/v1/chat/completions", "api.together.ai/settings/api-keys", false, false),
    PERPLEXITY("perplexity", "Perplexity (text only)", "sonar", "https://api.perplexity.ai/chat/completions", "perplexity.ai/settings/api", false, false),
    CUSTOM("custom", "Other (any OpenAI-compatible URL)", "", "", "", true, false);

    companion object {
        fun from(id: String): Provider = values().firstOrNull { it.id == id } ?: GEMINI
    }
}

/** API keys are kept in EncryptedSharedPreferences on the phone. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("fallback_prefs", Context.MODE_PRIVATE)
    }

    var provider: String
        get() = sp.getString("provider", Provider.GEMINI.id)!!
        set(v) = sp.edit().putString("provider", v).apply()

    fun key(p: Provider): String = sp.getString("key_${p.id}", "")!!
    fun setKey(p: Provider, v: String) = sp.edit().putString("key_${p.id}", v.trim()).apply()

    fun model(p: Provider): String = sp.getString("model_${p.id}", p.defaultModel)!!
    fun setModel(p: Provider, v: String) =
        sp.edit().putString("model_${p.id}", v.trim().ifEmpty { p.defaultModel }).apply()

    /** Language code the AI should reply in; empty = same as the user's. */
    var aiLang: String
        get() = sp.getString("ai_lang", "")!!
        set(v) = sp.edit().putString("ai_lang", v).apply()

    /** App (UI) language code; empty = system default. */
    var uiLang: String
        get() = sp.getString("ui_lang", "")!!
        set(v) = sp.edit().putString("ui_lang", v).apply()

    /** Only used by the "Other" provider. */
    var customUrl: String
        get() = sp.getString("custom_url", "")!!
        set(v) = sp.edit().putString("custom_url", v.trim()).apply()

    /** Generic string storage (plugin settings such as API keys, installed-plugin lists). */
    fun raw(k: String): String = sp.getString(k, "")!!
    fun setRaw(k: String, v: String) = sp.edit().putString(k, v).apply()
}
